import pygame
from pygame import mixer
from random import randrange


pygame.init()

# background music
pygame.mixer.music.load('bgm.mp3')
# set music volume(0 - 1)
pygame.mixer.music.set_volume(0.05)
# loops indefinitely
pygame.mixer.music.play(-1)

click_sound = mixer.Sound('click.wav')

width, height = 350, 650
w, h = 7, 13
block_width, block_height = 50, 50

speed = 1

difference = 10

score = 0

# colors
black = (0, 0, 0)
white = (255, 255, 255)
play_bg = (250, 208, 208)
block_colors = [(168, 168, 225), (177, 134, 227)]

# draw window
window = pygame.display.set_mode((width, height))
pygame.display.set_caption("STACKER")

clock = pygame.time.Clock()

# game states
menu, play, settings, h2p, over = range(5)
game_state = menu

# fonts for text
score_font = pygame.font.Font('BlocpartyRegular-0WGEP.ttf', 40)
hs_font = pygame.font.Font('BlocpartyRegular-0WGEP.ttf', 60)
text_font = pygame.font.Font('BlocpartyRegular-0WGEP.ttf', 70)
go_font = pygame.font.Font('BlocpartyRegular-0WGEP.ttf', 110)

# displayed images
logo_image = pygame.image.load("logo.png").convert_alpha()
logo = pygame.transform.scale(logo_image, (150, 210))
background_image = pygame.image.load("background.png").convert_alpha()
background = pygame.transform.scale(background_image, (350, 650))
how2play_image = pygame.image.load("how2play.png").convert_alpha()
how2play = pygame.transform.scale(how2play_image, (350, 650))

# displayed text
game = go_font.render("GAME", True, black)
over = go_font.render("OVER", True, black)


# class that displays buttons
class Button:

    def __init__(self, x, y, width, text):
        self.x = x
        self.y = y
        self.width = width
        self.text = text
        self.pressed = False
        self.button_color1 = (65, 110, 160)
        self.button_color2 = (30, 90, 160)
        self.text_color = (0, 0, 0)
        self.button_height = 70

    def draw_button(self):

        action = False

        # mouse position
        mouse = pygame.mouse.get_pos()

        button_rect = pygame.Rect(self.x, self.y, self.width, self.button_height)

        # if mouse is hovering button
        if button_rect.collidepoint(mouse):
            if pygame.mouse.get_pressed()[0] == 1:
                self.pressed = True
                pygame.draw.rect(window, self.button_color2, button_rect)

            elif pygame.mouse.get_pressed()[0] == 0 and self.pressed is True:
                self.pressed = False
                action = True

            else:
                pygame.draw.rect(window, self.button_color2, button_rect)

        else:
            pygame.draw.rect(window, self.button_color1, button_rect)

        letters = list(self.text)
        ng = 'g', 'j', 'p', 'q', 'y'

        # identify fall leters in text
        check = any(item in letters for item in ng)

        if check is False:
            added_height = 10
        # changes height if text contains fall letter
        elif check is True:
            added_height = 8

        # draws buttons with text
        button_text = text_font.render(self.text, True, self.text_color)
        text_length = button_text.get_width()
        window.blit(button_text, (self.x + int(self.width / 2) - int(text_length / 2), self.y + added_height))

        return action


# class that creates blocks
class Block:

    def __init__(self, x, y, color, speed):
        self.x = x
        self.y = y
        self.color = color
        self.speed = speed
        self.timer = 0
        self.size = 50


    # draws the stack on window
    def draw_stack(self):
        stack = pygame.Rect(self.x * self.size, self.y * self.size, self.size, self.size)
        pygame.draw.rect(window, self.color, stack)
        pygame.draw.rect(window, play_bg, stack, self.size//11)

    # changes the stacks direction
    def stack_movement(self):
        self.timer += 1
        if self.timer % difference == 0:
            self.x += self.speed
            if self.x > w:
                self.speed *= -1
            if self.x < -1:
                self.speed *= -1


class Stacker:

    def __init__(self):

        global block_colors

        self.stack_list = []

        self.buffer_stack_list = []

        self.stack_width = 3

        self.previous_stack_width = 3

        self.stack_height = 6

        self.total_blocks = 18

        self.buffer_total_blocks = 18
        
        self.block_color = block_colors[0]

        # creates base stack
        for i in range(self.stack_height):
            for x in range(self.stack_width):

                stack_new = Block(x + (w/2 - self.stack_width/2), h - (i + 1), self.block_color, 0)
                self.stack_list.append(stack_new)

            # alternates color for each stack
            if self.block_color == block_colors[0]:
                self.block_color = block_colors[1]

            elif self.block_color == block_colors[1]:
                self.block_color = block_colors[0]

    # displays blocks
    def display(self):
        for i in range(self.total_blocks):
            self.stack_list[i].draw_stack()

    # moves the active blocks
    def movement(self):
        for i in range(self.total_blocks):
            self.stack_list[i].stack_movement()

    # stops stack when space is pressed
    def press_space(self):
        global game_state, score

        self.buffer_stack_list = self.stack_list
        self.buffer_total_blocks = self.total_blocks

        # checks if any blocks align with the previous stack
        for i in range(self.stack_width):
            for x in range(self.previous_stack_width):
                # pb = previous block and b = block
                pb = self.stack_list[self.total_blocks - (x + 1 + self.stack_width)]
                b = self.stack_list[self.total_blocks - (i + 1)]
                # if blocks align, set their speed to zero
                if b.x == pb.x:
                    b.speed = 0

        # removes blocks that do not align
        for i in range(self.stack_width):
            b = self.stack_list[self.total_blocks - (i + 1)]
            if b.speed != 0:
                self.buffer_stack_list.remove(b)
                self.buffer_total_blocks -= 1
                self.stack_width -= 1
                self.previous_stack_width = self.stack_width

        self.stack_list = self.buffer_stack_list
        self.total_blocks = self.buffer_total_blocks

        # if no blocks align, game state is over
        if self.stack_width <= 0:
            game_state = over

        else:
            click_sound.play()
            score += 1

        # move all blocks down when new stack is added
        for i in range(self.total_blocks):
            a = self.stack_list[i]
            a.y += 1

    # creates a new stack when space is pressed
    def new_stack(self):

        global speed, draw_score, difference
        # randomizes the location that the stack spawns on (0 - 5)
        diff = randrange(6)

        if score > 25:
            difference += 0
        # increases speed
        elif score % 5 == 0:
            difference -= 1

        # spawns new stack on top of the previous stack
        for i in range(self.stack_width):
            y = self.stack_list[self.total_blocks - 1].y

            new_stack = Block(diff + i, y - 1, self.block_color, speed)

            self.stack_list.append(new_stack)

        if self.block_color == block_colors[0]:
            self.block_color = block_colors[1]

        elif self.block_color == block_colors[1]:
            self.block_color = block_colors[0]

        self.stack_height += 1
        self.total_blocks += self.stack_width

        # draws current score on window
        draw_score = score_font.render("Score: " + str(score), True, black)


# button locations and text
start_button = Button(100, 290, 150, "Start")
settings_button = Button(75, 380, 200, "Settings")
bgm_button0 = Button(25, 100, 50, "0")
bgm_button1 = Button(75, 100, 50, "1")
bgm_button2 = Button(125, 100, 50, "2")
bgm_button3 = Button(175, 100, 50, "3")
bgm_button4 = Button(225, 100, 50, "4")
bgm_button5 = Button(275, 100, 50, "5")
sfx_button0 = Button(25, 267.5, 50, "0")
sfx_button1 = Button(75, 267.5, 50, "1")
sfx_button2 = Button(125, 267.5, 50, "2")
sfx_button3 = Button(175, 267.5, 50, "3")
sfx_button4 = Button(225, 267.5, 50, "4")
sfx_button5 = Button(275, 267.5, 50, "5")
howtoplay_button = Button(50, 470, 250, "How to play")
exit_button = Button(100, 560, 150, "Exit")
back_button = Button(100, 560, 150, "Back")
replay_button = Button(90, 470, 170, "Replay")

run = True
# main loop
while run:

    # FPS
    clock.tick(60)

    for event in pygame.event.get():
        # exit program
        if event.type == pygame.QUIT:
            run = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and game_state == play:
                stacker.press_space()
                stacker.new_stack()

    if game_state == menu:

        window.blit(background, (0, 0))

        window.blit(logo, (100, 40))

        if start_button.draw_button():
            score = 0
            difference = 10
            stacker = Stacker()
            stacker.new_stack()
            game_state = play

        if settings_button.draw_button():
            game_state = settings

        if howtoplay_button.draw_button():
            game_state = h2p

        if exit_button.draw_button():
            run = False

    elif game_state == play:

        window.fill(play_bg)

        window.blit(draw_score, (10, 10))

        stacker.movement()

        stacker.display()

    elif game_state == settings:
        window.blit(background, (0, 0))

        bgm_volume = text_font.render("BGM Volume", True, black)
        window.blit(bgm_volume, (width/2 - bgm_volume.get_width()/2, bgm_volume.get_height()/2))

        # adjust bgm volume
        if bgm_button0.draw_button():
            pygame.mixer.music.set_volume(0)
        if bgm_button1.draw_button():
            pygame.mixer.music.set_volume(0.01)
        if bgm_button2.draw_button():
            pygame.mixer.music.set_volume(0.02)
        if bgm_button3.draw_button():
            pygame.mixer.music.set_volume(0.03)
        if bgm_button4.draw_button():
            pygame.mixer.music.set_volume(0.04)
        if bgm_button5.draw_button():
            pygame.mixer.music.set_volume(0.05)

        sfx_volume = text_font.render("SFX Volume", True, black)
        window.blit(sfx_volume, (width/2 - sfx_volume.get_width()/2, 170 + sfx_volume.get_height()/2))

        # adjust sfx volume
        if sfx_button0.draw_button():
            click_sound.set_volume(0)
        if sfx_button1.draw_button():
            click_sound.set_volume(0.2)
        if sfx_button2.draw_button():
            click_sound.set_volume(0.4)
        if sfx_button3.draw_button():
            click_sound.set_volume(0.6)
        if sfx_button4.draw_button():
            click_sound.set_volume(0.8)
        if sfx_button5.draw_button():
            click_sound.set_volume(1)

        if back_button.draw_button():
            game_state = menu

    elif game_state == h2p:
        window.blit(how2play, (0, 0))
        if back_button.draw_button():
            game_state = menu

    if game_state == over:
        window.blit(background, (0, 0))
        window.blit(game, (width/2 - game.get_width()/2, height/5))
        window.blit(over, (width/2 - over.get_width()/2, height/5 + game.get_height() - 10))

        # reads highscore from file
        highscore_file = open("highscore.txt", "r")
        highscore = highscore_file.read()
        highscore = int(highscore)        

        # replace highscore if new score is higher
        if score > highscore:
            new_highscore = open("highscore.txt", "r+")
            new_highscore.seek(0)
            str_score = str(score)
            new_highscore.write(str_score)

        # displays final score
        end_score = text_font.render("Score: " + str(score), True, black)
        window.blit(end_score, (width/2 - end_score.get_width()/2, height/2))

        # displays highscore
        highscore_text = hs_font.render("Highscore: " + str(highscore), True, black)
        window.blit(highscore_text, (width/2 - highscore_text.get_width()/2, height/2 + end_score.get_height()))

        # restart game
        if replay_button.draw_button():
            score = 0
            difference = 10
            stacker = Stacker()
            stacker.new_stack()
            game_state = play

        if back_button.draw_button():
            game_state = menu

    # update the window
    pygame.display.update()
