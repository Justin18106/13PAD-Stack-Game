import pygame


width, height = 360, 620


bg_color = (45, 50, 55)
brick_color = (65, 110, 160)


pygame.init()


window = pygame.display.set_mode((width, height))
window.fill(bg_color)
pygame.display.set_caption("STACKER")


clock = pygame.time.Clock()


menu, play, settings, help, over = range(5)
game_state = menu


text_font = pygame.font.Font('BlocpartyRegular-0WGEP.ttf', 70)


class Button():
    
    
    button_color = (65, 110, 160)
    button_color2 = (30, 90, 160)
    text_color = (0, 0, 0)
    height = 65
    
    
    def __init__(self, x, y, width, text):
        self.x = x
        self.y = y
        self.width = width
        self.text = text
        self.pressed = False
    
    
    def draw_button(self):
        
        action = False
        
        # mouse position
        mouse = pygame.mouse.get_pos()
        
        button_rect = pygame.Rect(self.x, self.y, self.width, self.height)
        
        # if mouse is hovering button
        if button_rect.collidepoint(mouse):
            if pygame.mouse.get_pressed()[0] == 1:
                self.pressed = True
            
            elif pygame.mouse.get_pressed()[0] == 0 and self.pressed == True:
                self.pressed = False
                action = True
                
        else:
            pygame.draw.rect(window, self.button_color, button_rect)
        
        button_text = text_font.render(self.text, True, self.text_color)
        text_length = button_text.get_width()
        text_height = button_text.get_height()
        window.blit(button_text, (self.x + int(self.width / 2) - int(text_length / 2), self.y + int(self.height / 2) - int(text_height / 2)))
        
        return action


start_button = Button(105, 275, 150, "Start")
settings_button = Button(80, 355, 200, "Settings")
howtoplay_button = Button(55, 435, 250, "How to play")
exit_button = Button(105, 515, 150, "Exit")


run = True
while run:
    
    
    clock.tick(60)


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False


        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                game_state = play
    
    
    if game_state == menu:
        if start_button.draw_button():
            game_state = play
            
        if settings_button.draw_button():
            game_state = settings
            
        if howtoplay_button.draw_button():
            game_state = help
            
        if exit_button.draw_button():
            run = False
            
    if game_state == play:
        window.fill(bg_color)
        

    pygame.display.update()

