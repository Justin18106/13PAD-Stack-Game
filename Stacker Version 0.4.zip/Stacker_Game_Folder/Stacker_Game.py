import pygame





pygame.init()

width, height = 350, 650
w, h = 7, 13
block_width, block_height = 50, 50

speed = 1

white = (255, 255, 255)
play_bg = (250, 208, 208)

window = pygame.display.set_mode((width, height))
window.fill(white)
pygame.display.set_caption("STACKER")

clock = pygame.time.Clock()

menu, play, settings, h2p, over = range(5)
game_state = menu

text_font = pygame.font.Font('BlocpartyRegular-0WGEP.ttf', 70)

logo_image = pygame.image.load("logo.png").convert_alpha()
logo = pygame.transform.scale(logo_image, (150, 210))
background_image = pygame.image.load("background.png").convert_alpha()
background = pygame.transform.scale(background_image, (350, 650))
how2play_image = pygame.image.load("how2play.png").convert_alpha()
how2play = pygame.transform.scale(how2play_image, (350, 650))





class Button:
    
    button_color1 = (65, 110, 160)
    button_color2 = (30, 90, 160)
    text_color = (0, 0, 0)
    button_height = 70
    
    
    def __init__(self, x, y, width, text):
        self.x = x
        self.y = y
        self.width = width
        self.text = text
        self.pressed = False
    
    
    def draw_button(self):
        
        action = False
        
        # mouse position
        mouse = pygame.mouse.get_pos()
        
        button_rect = pygame.Rect(self.x, self.y, self.width, self.button_height)
        
        # if mouse is hovering button
        if button_rect.collidepoint(mouse):
            if pygame.mouse.get_pressed()[0] == 1:
                self.pressed = True
                pygame.draw.rect(window, self.button_color2, button_rect)
            
            elif pygame.mouse.get_pressed()[0] == 0 and self.pressed == True:
                self.pressed = False
                action = True
                
            else:
                pygame.draw.rect(window, self.button_color2, button_rect)
                
        else:
            pygame.draw.rect(window, self.button_color1, button_rect)
        
        letters = list(self.text)
        ng = 'g', 'j', 'p', 'q', 'y'
        
        check = any(item in letters for item in ng)
        
        if check == False:
            number = 10
        
        elif check == True:
            number = 8
        
        button_text = text_font.render(self.text, True, self.text_color)
        text_length = button_text.get_width()
        window.blit(button_text, (self.x + int(self.width / 2) - int(text_length / 2), self.y + number))
        
        return action





class Block:
    
    timer = 0    
    size = 50
    block_color = (168, 168, 225)
    
    
    def __init__(self, x, y, speed):
        self.x = x
        self.y = y
        self.speed = speed
    
    
    def draw_stack(self):
        stack = pygame.Rect(self.x * self.size, self.y * self.size, self.size, self.size)
        pygame.draw.rect(window, self.block_color, stack)
        pygame.draw.rect(window, play_bg, stack, self.size//11)
        
        
    def stack_movement(self):
        #print(self.y)
        #print(self.speed)
        self.timer += 1
        if self.timer % 10 == 0:
            self.x += self.speed
            if self.x > w:
                self.speed *= -1
            if self.x + 1 < 0:
                self.speed *= -1             





class Stacker:
    
    size = 50
    
    def __init__(self):
        
        self.stack_list = []

        self.stack_width = 3
        
        self.stack_height = 6
        
        self.total_blocks = 18
        
        for i in range(self.stack_height):
            for x in range(self.stack_width):
                
                new_stack = Block(x + (w/2 - self.stack_width/2) , h - (i + 1), 0)
                self.stack_list.append(new_stack)


    def display(self):
        for i in range(self.total_blocks):
            self.stack_list[i].draw_stack()
            
            
    def movement(self):
        for i in range(self.total_blocks):
            #print(self.stack_list[i].speed)
            self.stack_list[i].stack_movement()
                   
            
            
    def new_stack(self):
        
        global speed
        
        for i in range(3):
            y = self.stack_list[self.stack_height * 3 - 1].y
            
            new_stack = Block(i + w/2 - self.stack_width/2, y - 1, speed)
            
            self.stack_list.append(new_stack)
            
        self.stack_height += 1
        self.total_blocks += 3





start_button = Button(100, 290, 150, "Start")
settings_button = Button(75, 380, 200, "Settings")
howtoplay_button = Button(50, 470, 250, "How to play")
exit_button = Button(100, 560, 150, "Exit")
back_button = Button(100, 560, 150, "Back")





run = True

while run:
    
    clock.tick(60)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and game_state == play:
                stacker.new_stack()
                
        



                
    if game_state == menu:
        
        window.blit(background, (0, 0))
        
        window.blit(logo, (100, 40))
        
        if start_button.draw_button():
            stacker = Stacker()
            stacker.new_stack()
            game_state = play
            
        if settings_button.draw_button():
            game_state = settings
            
        if howtoplay_button.draw_button():
            game_state = h2p
            
        if exit_button.draw_button():
            run = False




       
    elif game_state == play:
        
        window.fill(play_bg)
        
        stacker.movement()
        
        stacker.display()

        
        
        
        
    elif game_state == h2p:
        window.blit(how2play, (0, 0))
        if back_button.draw_button():
            game_state = menu
    
    
    
    
    
    pygame.display.update()

